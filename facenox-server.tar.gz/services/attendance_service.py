import logging
import asyncio
from datetime import datetime, timedelta
from typing import List, Optional, Any, Dict
import ulid
import numpy as np
import cv2

from api.schemas import AttendanceEventResponse, AttendanceTimeHealthResponse
from database.repository import AttendanceRepository
from services.time_authority_service import get_time_authority
from time_utils import (
    ensure_local_aware,
    from_storage_local,
    local_day_bounds,
    local_date_string,
    local_now,
    to_api_utc,
    to_storage_local,
)

logger = logging.getLogger(__name__)
_background_tasks: set = set()


class AttendanceService:
    def __init__(
        self,
        repo: AttendanceRepository,
        face_detector=None,
        face_recognizer=None,
        ws_manager=None,
    ):
        self.repo = repo
        self.face_detector = face_detector
        self.face_recognizer = face_recognizer
        self.ws_manager = ws_manager
        self.time_authority = get_time_authority()

    def generate_id(self) -> str:
        """Generate a unique ID"""
        return ulid.ulid()

    async def generate_person_id(self, name: str, group_id: str = None) -> str:
        """Generate a unique person ID"""
        person_id = ulid.ulid()

        max_attempts = 10
        attempt = 0

        while attempt < max_attempts:
            existing_member = await self.repo.get_member(person_id)
            if not existing_member:
                break

            person_id = ulid.ulid()
            attempt += 1

        return person_id

    @staticmethod
    def _normalize_rule(
        rule: Optional[Any],
        *,
        late_threshold_minutes: int,
        class_start_time: Optional[str],
        late_threshold_enabled: bool,
        track_checkout: bool,
    ) -> Dict[str, Any]:
        if rule is None:
            return {
                "id": None,
                "late_threshold_minutes": late_threshold_minutes,
                "class_start_time": class_start_time or local_now().strftime("%H:%M"),
                "late_threshold_enabled": late_threshold_enabled,
                "track_checkout": track_checkout,
            }

        return {
            "id": getattr(rule, "id", None),
            "late_threshold_minutes": getattr(
                rule, "late_threshold_minutes", late_threshold_minutes
            ),
            "class_start_time": getattr(
                rule,
                "class_start_time",
                class_start_time or local_now().strftime("%H:%M"),
            ),
            "late_threshold_enabled": getattr(
                rule, "late_threshold_enabled", late_threshold_enabled
            ),
            "track_checkout": getattr(rule, "track_checkout", track_checkout),
        }

    @staticmethod
    def _select_effective_rule(
        rule_history: Optional[List[Any]],
        effective_at: datetime,
    ) -> Optional[Any]:
        if not rule_history:
            return None

        selected_rule = None
        for rule in rule_history:
            rule_effective_from = getattr(rule, "effective_from", None)
            if rule_effective_from is None or rule_effective_from <= effective_at:
                selected_rule = rule
            else:
                break

        return selected_rule or rule_history[0]

    @staticmethod
    def _calculate_late_status(
        check_in_time: datetime, rule: Dict[str, Any]
    ) -> tuple[bool, Optional[int]]:
        if not rule.get("late_threshold_enabled"):
            return False, None

        localized_check_in = ensure_local_aware(from_storage_local(check_in_time))

        class_start_time = rule.get("class_start_time") or local_now().strftime("%H:%M")
        try:
            start_hour, start_minute = [
                int(part) for part in class_start_time.split(":")
            ]
        except (TypeError, ValueError, AttributeError):
            start_hour, start_minute = 8, 0

        late_threshold_minutes = int(rule.get("late_threshold_minutes") or 0)

        check_in_hour = localized_check_in.hour
        is_early_morning_arrival = 0 <= check_in_hour < 4
        is_late_night_start = 20 <= start_hour <= 23

        base_date = localized_check_in
        if is_early_morning_arrival and is_late_night_start:
            base_date = localized_check_in - timedelta(days=1)

        day_start = base_date.replace(
            hour=start_hour, minute=start_minute, second=0, microsecond=0
        )
        time_diff_minutes = (localized_check_in - day_start).total_seconds() / 60
        is_late = time_diff_minutes > late_threshold_minutes
        if not is_late:
            return False, None

        # Minutes late should reflect lateness against the scheduled start time.
        return True, max(0, int(time_diff_minutes))

    def compute_sessions_from_records(
        self,
        records: List[Any],
        members: List[Any],
        late_threshold_minutes: int,
        target_date: str,
        class_start_time: str = None,
        late_threshold_enabled: bool = False,
        existing_sessions: Optional[List[Any]] = None,
        track_checkout: bool = False,
        rule_history: Optional[List[Any]] = None,
    ) -> List[dict]:
        """Compute attendance sessions from records using effective-dated group rules."""
        sessions = []

        existing_sessions_map = {}
        if existing_sessions:
            for session in existing_sessions:
                existing_sessions_map[session.person_id] = session

        records_by_person = {}
        for record in records:
            person_id = record.person_id
            if person_id not in records_by_person:
                records_by_person[person_id] = []
            records_by_person[person_id].append(record)

        try:
            target_date_obj = datetime.strptime(target_date, "%Y-%m-%d").date()
        except (ValueError, TypeError):
            target_date_obj = None

        for member in members:
            person_id = member.person_id

            # Check if this session was manually overridden (has non-empty notes)
            existing_session = existing_sessions_map.get(person_id)
            if existing_session and existing_session.notes:
                sessions.append(
                    {
                        "id": existing_session.id,
                        "person_id": person_id,
                        "group_id": existing_session.group_id,
                        "applied_rule_id": existing_session.applied_rule_id,
                        "date": target_date,
                        "check_in_time": existing_session.check_in_time,
                        "check_out_time": existing_session.check_out_time,
                        "total_hours": existing_session.total_hours,
                        "status": existing_session.status,
                        "is_late": existing_session.is_late,
                        "late_minutes": existing_session.late_minutes,
                        "notes": existing_session.notes,
                    }
                )
                continue

            # Check if member was enrolled on or before target_date
            if target_date_obj is not None and member.joined_at:
                try:
                    joined_at = member.joined_at
                    # joined_at is datetime in SQLAlchemy model
                    joined_at_obj = joined_at.date()

                    if joined_at_obj and target_date_obj < joined_at_obj:
                        continue

                    today = local_now().date()
                    if joined_at_obj and joined_at_obj > today:
                        continue
                except (ValueError, TypeError, AttributeError) as e:
                    logger.debug(f"Error comparing dates for member {person_id}: {e}")

            person_records = records_by_person.get(person_id, [])

            if not person_records:
                existing_session = existing_sessions_map.get(person_id)
                sessions.append(
                    {
                        "id": (
                            existing_session.id
                            if existing_session
                            else self.generate_id()
                        ),
                        "person_id": person_id,
                        "group_id": member.group_id,
                        "applied_rule_id": None,
                        "date": target_date,
                        "check_in_time": None,
                        "status": "absent",
                        "is_late": False,
                        "late_minutes": None,
                        "notes": existing_session.notes if existing_session else None,
                    }
                )
                continue

            person_records.sort(key=lambda r: r.timestamp)

            first_record = person_records[0]
            timestamp = first_record.timestamp  # earliest check-in for the day
            # Get the rule in effect at the end of the target day, so settings updates made during the day apply to the day's session
            rule_effective_time = timestamp.replace(
                hour=23, minute=59, second=59, microsecond=999999
            )
            selected_rule = self._select_effective_rule(
                rule_history, rule_effective_time
            )
            normalized_rule = self._normalize_rule(
                selected_rule,
                late_threshold_minutes=late_threshold_minutes,
                class_start_time=class_start_time,
                late_threshold_enabled=late_threshold_enabled,
                track_checkout=track_checkout,
            )
            is_late, late_minutes = self._calculate_late_status(
                timestamp, normalized_rule
            )

            existing_session = existing_sessions_map.get(person_id)
            should_track_checkout = bool(normalized_rule.get("track_checkout"))
            sessions.append(
                {
                    "id": (
                        existing_session.id if existing_session else self.generate_id()
                    ),
                    "person_id": person_id,
                    "group_id": member.group_id,
                    "applied_rule_id": normalized_rule.get("id"),
                    "date": target_date,
                    "check_in_time": timestamp,
                    "check_out_time": (
                        person_records[-1].timestamp
                        if should_track_checkout and len(person_records) > 1
                        else None
                    ),
                    "total_hours": (
                        (person_records[-1].timestamp - timestamp).total_seconds()
                        / 3600.0
                        if should_track_checkout and len(person_records) > 1
                        else None
                    ),
                    "status": "present",
                    "is_late": is_late,
                    "late_minutes": late_minutes,
                    "notes": existing_session.notes if existing_session else None,
                }
            )

        return sessions

    def calculate_group_stats(self, members: List[Any], sessions: List[Any]) -> dict:
        """Calculate group attendance statistics"""
        total_members = len(members)
        present_today = 0
        absent_today = 0
        late_today = 0

        session_map = {session.person_id: session for session in sessions}

        for member in members:
            person_id = member.person_id
            session = session_map.get(person_id)

            if session:
                status = session.status
                if status == "present":
                    present_today += 1
                    if session.is_late:
                        late_today += 1
                else:
                    absent_today += 1
            else:
                absent_today += 1

        return {
            "total_members": total_members,
            "present_today": present_today,
            "absent_today": absent_today,
            "late_today": late_today,
        }

    async def recompute_sessions_for_date(
        self,
        group_id: str,
        target_date: str,
        *,
        person_id: Optional[str] = None,
    ) -> List[dict]:
        """Rebuild derived sessions for a group/date after record corrections."""
        group = await self.repo.get_group(group_id)
        if not group:
            raise ValueError("Group not found")

        if person_id:
            member = await self.repo.get_member(person_id)
            if not member or member.group_id != group_id:
                raise ValueError("Member not found")
            members = [member]
        else:
            members = await self.repo.get_group_members(group_id)

        existing_sessions = await self.repo.get_sessions(
            group_id=group_id,
            person_id=person_id,
            start_date=target_date,
            end_date=target_date,
        )
        rule_history = await self.repo.get_group_rules(group_id)
        start_of_day, end_of_day = local_day_bounds(target_date)
        records = await self.repo.get_records(
            group_id=group_id,
            person_id=person_id,
            start_date=start_of_day,
            end_date=end_of_day,
        )

        session_dicts = self.compute_sessions_from_records(
            records=records,
            members=members,
            late_threshold_minutes=group.late_threshold_minutes or 15,
            target_date=target_date,
            class_start_time=group.class_start_time,
            late_threshold_enabled=group.late_threshold_enabled or False,
            existing_sessions=existing_sessions,
            track_checkout=getattr(group, "track_checkout", False),
            rule_history=rule_history,
        )

        await self.repo.upsert_sessions(session_dicts)

        return session_dicts

    async def process_event(
        self, event_data, member, settings
    ) -> AttendanceEventResponse:
        """Process an attendance event"""
        cooldown_seconds = settings.attendance_cooldown_seconds or 300

        time_health = await self.time_authority.get_time_health()
        time_health_payload = AttendanceTimeHealthResponse.model_validate(
            time_health.__dict__
        ).model_dump(mode="json")
        current_time = to_storage_local(time_health.current_time_local)
        window_seconds = cooldown_seconds

        recent_records = await self.repo.get_records(
            person_id=event_data.person_id,
            start_date=current_time - timedelta(seconds=window_seconds),
            end_date=current_time,
            limit=20,
        )

        today_str = local_date_string(time_health.current_time_local)

        # Get group settings for late threshold and check-out tracking
        group = await self.repo.get_group(member.group_id)

        existing_session = await self.repo.get_session(event_data.person_id, today_str)

        # Ensure single source of truth for cooldown based on UI settings
        if recent_records:
            for record in recent_records:
                record_time = record.timestamp
                time_diff = (current_time - record_time).total_seconds()

                if time_diff < cooldown_seconds:
                    return AttendanceEventResponse(
                        id=None,
                        person_id=event_data.person_id,
                        group_id=member.group_id,
                        timestamp=current_time,
                        confidence=event_data.confidence,
                        location=event_data.location,
                        processed=False,
                        error=f"Cooldown active. Wait {int(cooldown_seconds - time_diff)}s.",
                        time_health=time_health_payload,
                    )

        record_id = self.generate_id()
        timestamp = current_time

        record_data = {
            "id": record_id,
            "person_id": event_data.person_id,
            "group_id": member.group_id,
            "timestamp": timestamp,
            "confidence": event_data.confidence,
            "location": event_data.location,
            "notes": None,
            "is_manual": False,
            "created_by": None,
        }

        await self.repo.add_record(record_data)

        # Always fetch the effective rule at the current event time to support settings changes midway through the day
        session_rule = await self.repo.get_effective_group_rule(
            member.group_id, current_time
        )

        normalized_rule = self._normalize_rule(
            session_rule,
            late_threshold_minutes=group.late_threshold_minutes or 15,
            class_start_time=group.class_start_time
            or time_health.current_time_local.strftime("%H:%M"),
            late_threshold_enabled=group.late_threshold_enabled or False,
            track_checkout=getattr(group, "track_checkout", False),
        )

        # Determine event type and session data
        event_type = "check_in"
        check_in_time = timestamp
        check_out_time = None
        total_hours = None

        if existing_session and existing_session.check_in_time:
            check_in_time = existing_session.check_in_time
            if normalized_rule["track_checkout"]:
                event_type = "check_out"
                check_out_time = timestamp
                duration = check_out_time - check_in_time
                total_hours = max(0, duration.total_seconds() / 3600.0)
            else:
                # Preserve earliest check-in if not tracking check-out
                check_in_time = min(existing_session.check_in_time, timestamp)

        is_late, late_minutes = self._calculate_late_status(
            check_in_time, normalized_rule
        )

        session_data = {
            "id": (existing_session.id if existing_session else self.generate_id()),
            "person_id": event_data.person_id,
            "group_id": member.group_id,
            "applied_rule_id": normalized_rule.get("id"),
            "date": today_str,
            "check_in_time": check_in_time,
            "check_out_time": check_out_time,
            "total_hours": total_hours,
            "status": "present",
            "is_late": is_late,
            "late_minutes": late_minutes,
            "notes": None,
        }

        await self.repo.upsert_session(session_data)

        if self.ws_manager:
            broadcast_message = {
                "type": "attendance_event",
                "data": {
                    "id": record_id,
                    "person_id": event_data.person_id,
                    "group_id": member.group_id,
                    "timestamp": to_api_utc(timestamp).isoformat(),
                    "confidence": event_data.confidence,
                    "location": event_data.location,
                    "event_type": event_type,
                    "check_in_time": (
                        to_api_utc(check_in_time).isoformat() if check_in_time else None
                    ),
                    "check_out_time": (
                        to_api_utc(check_out_time).isoformat()
                        if check_out_time
                        else None
                    ),
                    "total_hours": total_hours,
                    "time_health": (
                        time_health_payload if time_health.warning_message else None
                    ),
                    "member": {
                        "name": member.name,
                        "role": member.role,
                    },
                },
            }
            task = asyncio.create_task(self.ws_manager.broadcast(broadcast_message))
            _background_tasks.add(task)
            task.add_done_callback(_background_tasks.discard)

        return AttendanceEventResponse(
            id=record_id,
            person_id=event_data.person_id,
            group_id=member.group_id,
            timestamp=timestamp,
            confidence=event_data.confidence,
            location=event_data.location,
            processed=True,
            event_type=event_type,
            error=None,
            time_health=time_health_payload,
        )

    async def enroll_member(
        self,
        group_id: str,
        person_id: str,
        image: np.ndarray,
        bbox: List[float],
        landmarks_5: List[List[float]],
    ) -> Dict[str, Any]:
        """Enroll member for recognition in a group."""
        if not self.face_recognizer:
            raise ValueError("Face recognition system not available")

        group = await self.repo.get_group(group_id)
        if not group:
            raise ValueError("Group not found")

        member = await self.repo.get_member(person_id)
        if not member:
            raise ValueError("Member not found")

        if member.group_id != group_id:
            raise ValueError("Member does not belong to this group")

        if not member.has_consent:
            raise PermissionError(
                "Biometric consent is required before face enrollment"
            )

        from hooks import process_face_detection

        detections = await process_face_detection(
            image, min_face_size=0, enable_liveness=False
        )
        if not detections:
            raise ValueError("No detectable face found in image")

        result = await self.face_recognizer.enroll_person(
            person_id, image, landmarks_5, self.repo.organization_id
        )

        if result["success"]:
            logger.info(
                f"Face enrolled successfully for {person_id}. Total persons: {result.get('total_persons', 0)}"
            )
            return {
                "success": True,
                "message": f"Face enrolled successfully for {person_id} in group {group.name}",
                "person_id": person_id,
                "group_id": group_id,
                "total_persons": result.get("total_persons", 0),
            }
        else:
            logger.error(
                f"Face enrollment failed for {person_id}: {result.get('error', 'Unknown error')}"
            )
            raise ValueError(result.get("error", "Face enrollment failed"))

    async def remove_face_data(self, group_id: str, person_id: str) -> Dict[str, Any]:
        """Remove face data for a person"""
        if not self.face_recognizer:
            raise ValueError("Face recognition system not available")

        group = await self.repo.get_group(group_id)
        if not group:
            raise ValueError("Group not found")

        member = await self.repo.get_member(person_id)
        if not member:
            raise ValueError("Member not found")

        if member.group_id != group_id:
            raise ValueError("Member does not belong to this group")

        result = await self.face_recognizer.remove_person(
            person_id, self.repo.organization_id
        )

        if result["success"]:
            return {
                "success": True,
                "message": f"Face data removed for {person_id} in group {group.name}",
                "person_id": person_id,
                "group_id": group_id,
            }
        else:
            raise ValueError("Face data not found for this person")

    async def bulk_detect_faces_in_files(
        self, group_id: str, images: list
    ) -> Dict[str, Any]:
        """Detect faces in multiple uploaded binary files (Multipart)"""
        if not self.face_detector:
            raise ValueError("Face detection system not available")

        group = await self.repo.get_group(group_id)
        if not group:
            raise ValueError("Group not found")

        results = []
        from hooks import process_face_detection

        for idx, file in enumerate(images):
            image_id = f"image_{idx}"
            try:
                contents = await file.read()
                nparr = np.frombuffer(contents, np.uint8)
                image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

                if image is None:
                    results.append(
                        {
                            "image_id": image_id,
                            "success": False,
                            "error": "Failed to decode image",
                            "faces": [],
                        }
                    )
                    continue

                detections = await process_face_detection(image)

                processed_faces = []
                for face in detections:
                    processed_faces.append(
                        {
                            "bbox": face.get("bbox"),
                            "confidence": face.get("confidence", 0.0),
                            "landmarks_5": face.get("landmarks_5"),
                            "quality_score": 0.8,
                            "is_acceptable": True,
                        }
                    )

                results.append(
                    {
                        "image_id": image_id,
                        "success": True,
                        "faces": processed_faces,
                        "total_faces": len(processed_faces),
                    }
                )

            except Exception as e:
                logger.error(f"Error processing image {image_id}: {e}")
                results.append(
                    {
                        "image_id": image_id,
                        "success": False,
                        "error": str(e),
                        "faces": [],
                    }
                )
            finally:
                await file.close()

        return {
            "success": True,
            "group_id": group_id,
            "total_images": len(images),
            "results": results,
        }

    async def bulk_enroll_with_files(
        self, group_id: str, registrations: list, files: list
    ) -> Dict[str, Any]:
        """Bulk enroll members for recognition from uploaded binary files (Multipart)"""
        if not self.face_recognizer:
            raise ValueError("Face recognition system not available")

        group = await self.repo.get_group(group_id)
        if not group:
            raise ValueError("Group not found")

        file_map = {f.filename: f for f in files if f.filename}
        file_list = [f for f in files]

        success_count = 0
        failed_count = 0
        results = []

        for idx, reg_data in enumerate(registrations):
            person_id = reg_data.get("person_id")
            filename = reg_data.get("filename")

            try:
                file = None
                if filename and filename in file_map:
                    file = file_map[filename]
                elif idx < len(file_list):
                    file = file_list[idx]

                if not file:
                    failed_count += 1
                    results.append(
                        {
                            "index": idx,
                            "person_id": person_id,
                            "success": False,
                            "error": "No image file matched",
                        }
                    )
                    continue

                member = await self.repo.get_member(person_id)
                if not member or member.group_id != group_id:
                    failed_count += 1
                    results.append(
                        {"index": idx, "success": False, "error": "Invalid member"}
                    )
                    continue

                if not member.has_consent:
                    failed_count += 1
                    results.append(
                        {
                            "index": idx,
                            "person_id": person_id,
                            "success": False,
                            "error": "Biometric consent required",
                        }
                    )
                    continue

                contents = await file.read()
                nparr = np.frombuffer(contents, np.uint8)
                image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

                if image is None:
                    failed_count += 1
                    results.append(
                        {
                            "index": idx,
                            "person_id": person_id,
                            "success": False,
                            "error": "Failed to decode image",
                        }
                    )
                    continue

                from hooks import process_face_detection

                detections = await process_face_detection(
                    image, min_face_size=0, enable_liveness=False
                )
                if not detections:
                    failed_count += 1
                    results.append(
                        {
                            "index": idx,
                            "person_id": person_id,
                            "success": False,
                            "error": "No detectable face found in image",
                        }
                    )
                    continue

                landmarks_5 = reg_data.get("landmarks_5")
                if landmarks_5 is None:
                    failed_count += 1
                    results.append(
                        {
                            "index": idx,
                            "person_id": person_id,
                            "success": False,
                            "error": "Landmarks required",
                        }
                    )
                    continue

                result = await self.face_recognizer.enroll_person(
                    person_id, image, landmarks_5, self.repo.organization_id
                )

                if result["success"]:
                    success_count += 1
                    results.append(
                        {"index": idx, "person_id": person_id, "success": True}
                    )
                else:
                    failed_count += 1
                    results.append(
                        {
                            "index": idx,
                            "person_id": person_id,
                            "success": False,
                            "error": result.get("error"),
                        }
                    )

            except Exception as e:
                logger.error(f"Error in bulk enroll item {idx}: {e}")
                failed_count += 1
                results.append(
                    {
                        "index": idx,
                        "person_id": person_id,
                        "success": False,
                        "error": str(e),
                    }
                )
            finally:
                if file:
                    await file.close()

        return {
            "success": True,
            "group_id": group_id,
            "success_count": success_count,
            "failed_count": failed_count,
            "results": results,
        }
